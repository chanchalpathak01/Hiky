import React, {useState, useEffect } from 'react';
import './PaymentPage.css'; // Import your CSS file for styling
import { useParams } from 'react-router-dom';
const PaymentPage = (props) => {
    // JavaScript code from the original HTML file
  const {id} = useParams();

  // useEffect(() => {

  // },[]);
    const [form, setForm] = useState({});

    const handleDoFun =()=> {
      let tColorA = document.getElementById('tColorA');
      let tColorB = document.getElementById('tColorB');
      let tColorC = document.getElementById('tColorC');
      // let iconA = document.querySelector('.fa-credit-card');
      // let iconB = document.querySelector('.fa-building-columns');
      // let iconC = document.querySelector('.fa-wallet');
      let cDetails = document.querySelector('.card-details1');

      tColorA.style.color = "greenyellow";
      tColorB.style.color = "#444";
      tColorC.style.color = "#444";
      // iconA.style.color = "greenyellow";
      // iconB.style.color = "#aaa";
      // iconC.style.color = "#aaa";
      cDetails.style.display = "block";
    };

    const handleDoFunA = () => {
      let tColorA = document.getElementById('tColorA');
      let tColorB = document.getElementById('tColorB');
      let tColorC = document.getElementById('tColorC');
      // let iconA = document.querySelector('.fa-credit-card');
      // let iconB = document.querySelector('.fa-building-columns');
      // let iconC = document.querySelector('.fa-wallet');
      let cDetails = document.querySelector('.card-details1');

      tColorA.style.color = "#444";
      tColorB.style.color = "greenyellow";
      tColorC.style.color = "#444";
      // iconA.style.color = "#aaa";
      // iconB.style.color = "greenyellow";
      // iconC.style.color = "#aaa";
      cDetails.style.display = "none";
    };

    const handleDoFunB = () => {
      let tColorA = document.getElementById('tColorA');
      let tColorB = document.getElementById('tColorB');
      let tColorC = document.getElementById('tColorC');
      // let iconA = document.querySelector('.fa-credit-card');
      // let iconB = document.querySelector('.fa-building-columns');
      // let iconC = document.querySelector('.fa-wallet');
      let cDetails = document.querySelector('.card-details1');

      tColorA.style.color = "#444";
      tColorB.style.color = "#444";
      tColorC.style.color = "greenyellow";
      // iconA.style.color = "#aaa";
      // iconB.style.color = "#aaa";
      // iconC.style.color = "greenyellow";
      cDetails.style.display = "none";
    };

    const handleInp = (e) => {
        setForm({...form,
        [e.target.id]:e.target.value});
    }

    const handleSubmit = async (e) => {

        e.preventDefault();
        alert("form submitted successfully");
        console.log(form);
    }
    // let cNumber = document.querySelector('#number');
    const handleCardNumber = (e) => {
      let num = e.target.value;
      let newValue = '';
      num = num.replace(/\s/g, '');
      for (var i = 0; i < num.length; i++) {
        if (i % 4 === 0 && i > 0) newValue = newValue.concat(' ');
        newValue = newValue.concat(num[i]);
        e.target.value = newValue;
        setForm({...form,
        [e.target.id] : e.target.value});
      }
      let ccNum = document.getElementById('c-number');
      if (num.length < 16) {
        ccNum.style.border = "1px solid red";
      } else {
        ccNum.style.border = "1px solid greenyellow";
      }
    };

    // 
    const handleDate = (e) => {
      let newInput = e.target.value;

      let inp = "";
    //   newInput = newInput.replace("","/");
      if(newInput.length <= 5)
      {
        if(newInput.length === 2)
        newInput = newInput.concat("/");
        
        e.target.value = newInput;
        console.log(inp);
        setForm({...form,
        [e.target.id] : e.target.value
    })
      }
    //   if(newInput.length <= 5)
    //   {
    //     var numChars = e.target.value.length;
    //     if (numChars === 2) {
    //       var thisVal = e.target.value;
    //       thisVal += '/';
    //       e.target.value = thisVal;
    //     }
        
    //     e.target.value = "jh"; 
    //     setForm({...form,
    //     [e.target.id]: e.target.value});
    // // }

      let eDate = document.getElementById('e-date');
      if (newInput.length < 5) {
        eDate.style.border = "1px solid red";
      } else {
        eDate.style.border = "1px solid greenyellow";
      }
    };

    
    const handleCvv = (e) => {
      let elen = e.target.value;
      let cvvBox = document.getElementById('cvv-box');
      setForm({...form,
    [e.target.id] : e.target.value});
      if (elen.length < 3) {
        cvvBox.style.border = "1px solid red";
      } else {
        cvvBox.style.border = "1px solid greenyellow";
      }
    };

  return (
    <div className="background1">
      <div className="container1">
        <div className="left1">
          <p>Payment methods</p>
          <hr />
          <div className="methods1">
            <div className="payment-method" onClick={handleDoFun} id="tColorA">
              {/* <i className="fa-solid fa-credit-card"></i> */}
               Payment by card
            </div>
            <div className="payment-method" onClick={handleDoFunA} id="tColorB">
              {/* <i className="fa-solid fa-building-columns"></i> */}
              Internet banks
            </div>
            <div className="payment-method" onClick={handleDoFunB} id="tColorC">
              {/* <i className="fa-solid fa-wallet"></i>  */}
              Apple/Google pay
            </div>
          </div>
          <hr />
        </div>
        <div className="center1">
          <a href="https://www.shift4shop.com/credit-card-logos.html">
            <img alt="Credit Card Logos" title="Credit Card Logos" src="https://www.shift4shop.com/images/credit-card-logos/cc-lg-4.png" width="250" height="auto" />
          </a>
          <hr />
          <div className="card-details1">
            <form onSubmit={handleSubmit}>
              <p>Card number</p>
              <div className="c-number1" id="c-number">
                <input id="number" className="cc-number1" onChange={handleCardNumber} placeholder="Card number" maxLength="19" required />
                {/* <i className="fa-solid fa-credit-card"></i> */}
              </div>
              <div className="c-details1">
                <div id="date-box">
                  <p>Expiry date</p>
                  <input id="e-date" className="cc-exp1" onChange={handleDate} placeholder="MM/YY" required maxLength="5" />
                </div>
                <div>
                  <p>CVV</p>
                  <div className="cvv-box1" id="cvv-box">
                    <input id="cvv" className="cc-cvv1" onChange={handleCvv} placeholder="CVV" required maxLength="3"  />
                    <i className="fa-solid fa-circle-question" title="3 digits on the back of the card"></i>
                  </div>
                </div>
              </div>
              <div className="email1">
                <p>Email</p>
                <input type="email" onChange ={handleInp} placeholder="example@email.com" id="email" required />
              </div>
              <button type='submit'>PAY NOW</button>
            </form>
          </div>
        </div>
        <div className="right">
          <p>Amount : INR {id}</p>
          <hr />
          
          <hr />
          <a href="https://www.shift4shop.com/credit-card-logos.html">
            <img alt="Credit Card Logos" title="Credit Card Logos" src="https://www.shift4shop.com/images/credit-card-logos/cc-lg-4.png" width="100%" height="auto" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
