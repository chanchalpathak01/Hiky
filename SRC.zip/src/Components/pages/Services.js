import React from 'react';
import CardItem from '../CardItem';
import Footer from '../Footer';

import '../../App.css';
import '../Cards.css';
import './Services.css';

export default function Services() {
  return (
    <>
      <h1 className='services'>SERVICES</h1>
      <section className='heading'>
        <h2>Activities we think you would enjoy</h2>
        <div className='services-container'>
          <div className='services-wrapper'> 
          <ul className='services-items'>
          <CardItem 
              src="Devkund.png"
              text="Explore the hidden waterfall deep inside Devkund!"
              label="Adventure"
              path="/services/activity"
            ></CardItem>
            <CardItem 
              src="Kalsubai.jpg"
              text="Highest Peak of Maharashtra!"
              label="Adventure"
              path="/services/activity"
            ></CardItem>
            <CardItem 
              src="Harishchandra.png"
              text="Strongly Fortified "
              label="Adventure"
              path="/services/activity"
            ></CardItem>
            <CardItem 
              src="Aadrai.jpg"
              text="Unexplored jungle Trek!"
              label="Adventure"
              path="/services/activity"
            ></CardItem>
            <CardItem 
              src="Sondai.png"
              text="Hidden gem in Karjat!"
              label="Adventure"
              path="/services/activity"
            ></CardItem>
          </ul>
          </div>
        </div>
      </section>

      <section className='heading'>
        <h2>Explore these destinations</h2>
        <div className='services-container'>
          <div className='services-wrapper'> 
          <ul className='services-items'>
          <CardItem 
              src="kothaligad.png"
              text="Kothaligad"
              label = "Maharashtra"
              path="/services/activity"
            ></CardItem>
            <CardItem 
              src="Ratangad.jpg"
              text="Ratangad"
              label = "Maharashtra"
              path="/services/activity"
            ></CardItem>
            <CardItem 
              src="destination-3.jpg"
              text="Kalsubai.jpg"
              label = "Maharashtra"
              path="/services/activity"
            ></CardItem>
            <CardItem 
              src="kalsubai.jpg"
              text="kavnai"
              label = "Maharashtra"
              path="/services/activity"
            ></CardItem>
          </ul>
          </div>
        </div>
      </section>
      {/* <Footer /> */}
    </>
  
  
  );
}